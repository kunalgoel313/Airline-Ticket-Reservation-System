package com.cognizant.airline_ticket_reservation_system;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlineTicketReservationSystemApplicationTests {
    @Test
    void contextLoads() {
    }
}
